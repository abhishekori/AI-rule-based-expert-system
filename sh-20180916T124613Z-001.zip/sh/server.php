<?php
 echo $var = $_GET['window'];
//$command ="python servo.py ".$var;
//echo exec($command)
 ?>
