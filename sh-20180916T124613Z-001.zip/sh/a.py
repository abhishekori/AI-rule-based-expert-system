print "hi i am from python"
